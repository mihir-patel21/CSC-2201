
#include "HashTable.h"

template <typename DataType, typename KeyType>
HashTable<DataType, KeyType>::HashTable(int initTableSize)
// initial all the data members of the hashtable.
{
	tableSize = initTableSize;
	dataTable = new BSTree<DataType, KeyType>[initTableSize];
}

template <typename DataType, typename KeyType>
HashTable<DataType, KeyType>::HashTable(const HashTable& other)
// copy constructor: deep copy all the data members of "other" to "this"
{
	tableSize = 0;
	dataTable = NULL;
	*this = other;
}

template <typename DataType, typename KeyType>
HashTable<DataType,KeyType>& HashTable<DataType, KeyType>::operator=(const HashTable& other)
// assignment operator: delete the remaning object. Deep copy "other" object to this.
{
	if (this != &other)
	{
		clear();
		if (!other.isEmpty())
		{
			copyTable(other);
		}
	}
	return *this;
}

template <typename DataType, typename KeyType>
HashTable<DataType, KeyType>::~HashTable()
// destructor: free all the memmory used by the hashtable
{
	int index = 0;

	if (dataTable != NULL)
	{
		delete[] dataTable;
		dataTable = NULL;
	}
	tableSize = source.tableSize;

	dataTable = new BSTree<DataType, KeyType>[tableSize];

	for (index = 0; index < tableSize; index++)
	{
		dataTable[index] = source.dataTable[index];
	}
}

template <typename DataType, typename KeyType>
void HashTable<DataType, KeyType>::insert(const DataType& newDataItem)
// insert the newDataItem to the hashtable
// first get the "hash" number of the newDataItem (remember that DataType has the function hash - read the file test10)
// find the index of the array that the newDataItem belongs to (hashnumber % tableSize)
// use the insert function of the BStree at that index to insert the newDataItem
{

	unsigned int index = 0;

	index = DataType::hash(newDataItem.getKey());

	index %= tableSize;

	dataTable[index].insert(newDataItem);
}

template <typename DataType, typename KeyType>
bool HashTable<DataType, KeyType>::remove(const KeyType& deleteKey)
// same as insert, but use the remove function of the BStree the newDateItem at that index
{
	bool del = false;
	unsigned int index = 0;

	index = DataType::hash(deleteKey);

	index %= tableSize;

	del = dataTable[index].remove(deleteKey);

	return del;
}

template <typename DataType, typename KeyType>
bool HashTable<DataType, KeyType>::retrieve(const KeyType& searchKey, DataType& returnItem) const
// same as insert, but use the retrieve function of the BStree the newDateItem at that index
{
	bool retrive = false;
	unsigned int index = 0;

	index = DataType::hash(searchKey) % tableSize;

	retrive = dataTable[index].retrieve(searchKey, returnItem);

	return retrive;
}

template <typename DataType, typename KeyType>
void HashTable<DataType, KeyType>::clear()
// for all BStree in the array, use the clear function of the BStree class.
{
	int index = 0;

	for (index = 0; index < tableSize; index++)
	{
		dataTable[index].clear();
	}
}

template <typename DataType, typename KeyType>
bool HashTable<DataType, KeyType>::isEmpty() const
// hashtable is empty if all the BStree in it is empty.
{
	bool empty = true;
	int index = 0;

	for (index = 0; index < tableSize; index++)
	{
		if (!dataTable[index].isEmpty())
		{
			empty = false;
			break;
		}
	}
	return empty;
}

#include "show10.cpp"

template <typename DataType, typename KeyType>
double HashTable<DataType, KeyType>::standardDeviation() const
// 1.Work out the Mean (the simple average of the numbers)
// 2.Then for each number: subtract the Mean and square the result.
// 3.Then work out the mean of those squared differences.
// 4.Take the square root of that and we are done!
// example : https://www.mathsisfun.com/data/standard-deviation-formulas.html
{
}

template <typename DataType, typename KeyType>
void HashTable<DataType, KeyType>::copyTable(const HashTable& source)
// helper function for the copy constructor and assignment operator.
// no recursion needed. Just need a for loop.
// you might not need this function if you implemented the copy constructor and assignment operator correctly already.
{
}
