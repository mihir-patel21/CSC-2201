
#include "BSTree.h"

template <typename DataType, class KeyType>
BSTree<DataType, KeyType>::BSTreeNode::BSTreeNode ( const DataType &nodeDataItem, BSTreeNode *leftPtr, BSTreeNode *rightPtr )
// Creates a binary search tree node containing data item elem, left
// child pointer leftPtr, and right child pointer rightPtr.
  : dataItem(nodeDataItem),
    left(leftPtr),
    right(rightPtr)
{
	*this = other;
}

template < typename DataType, class KeyType >
BSTree<DataType, KeyType>::BSTree ()

// Creates an empty tree.
{
	root = NULL;
	counter = 0;
	cursor = NULL;
}

template < typename DataType, class KeyType >
BSTree<DataType, KeyType>::BSTree ( const BSTree<DataType,KeyType>& other )
//copy constructor
{
	*this = other;
}

template < typename DataType, class KeyType >
BSTree<DataType, KeyType>& BSTree<DataType, KeyType>:: operator= ( const BSTree<DataType,KeyType>& other )
// Sets a tree to be equivalent to the tree "other".
{
	if (this != other) 
	{
		clear();
		root = assignHelper(root);
	}
	return *this;
	// Remember avoid accidentally trying to set object to itself.
}

template < typename DataType, class KeyType >
BSTree<DataType, KeyType>::~BSTree ()
// Frees the memory used by a tree.
{
	clear();
	root = 0;
	root = NULL;
	counter = 0;
}

template < typename DataType, class KeyType >
void BSTree<DataType, KeyType>::insert ( const DataType& newDataItem )
// Inserts newDataItem into a tree. If an data item with the same key
// as newDataItem already exists in the tree, then updates that
// data item's data with newDataItem's data.
{
	if (isEmpty()) 
	{
		BSTreeNode* temp = root;
		root = new BSTreeNode(newDataItem, NULL, NULL);
		counter++;
	}
	else 
	{
		
		cursor = root;
		char direction = search(newDataItem.getKey());
		if (direction == 'l')
			cursor->left = new BSTreeNode(newDataItem, NULL, NULL);
		else if (direction == 'r')
			cursor->right = new BSTreeNode(newDataItem, NULL, NULL);
		else
			cout << "Cannot insert duplicates of the same item!\n\n";
		counter++;
	}
	cursor = root;
}

template < typename DataType, class KeyType >
bool BSTree<DataType, KeyType>::retrieve ( const KeyType& searchKey, DataType& searchDataItem ) const
// Searches a tree for the data item with key searchKey. If the data item
// is found, then copies the data item to searchDataItem and returns true.
// Otherwise, returns false with searchDataItem undefined.
{
	cursor = root;
	char direction = search(searchKey);
	if (direction == 'n') 
	{
		searchDataItem = cursor->dataItem;
		return true;
	}
	else 
	{
		return false;
	}
}

template < typename DataType, class KeyType >
bool BSTree<DataType, KeyType>::remove ( const KeyType& deleteKey )
// Removes the data item with key deleteKey from a tree. If the
// data item is found, then deletes it from the tree and returns true.
// Otherwise, returns false.
{
	if (isEmpty()) 
	{
		return false;
		cout << "Tree is empty!  Cannot remove." << endl;
	}
}

template < typename DataType, class KeyType >
void BSTree<DataType, KeyType>::writeKeys () const
// Outputs the keys in a tree in ascending order.

{
	if (isEmpty()) 
	{
		cout << "Empty tree!" << endl;
	}
	else 
	{
		writeKeysHelper(root);
	}
}

template < typename DataType, class KeyType >
void BSTree<DataType, KeyType>::clear ()

// Removes all the nodes from a tree.
{
	if (root == NULL && counter == 0) 
	{
		cout << "List is already empty!" << endl;
		cout << "Tree is already empty!" << endl;
	}
	else 
	{
		helpClear(root);
		root = NULL;
		counter = 0;
	}
}

template < typename DataType, class KeyType >
bool BSTree<DataType, KeyType>::isEmpty () const

// Returns true if a tree is empty. Otherwise returns false.

{
	if (root == NULL && counter == 0) 
	{
		return true;
	}
	else
	{
		return false;
	}
}

template < typename DataType, class KeyType >
int BSTree<DataType, KeyType>::getHeight () const
// Returns the height of a tree.

{
	int height;
	if (isEmpty()) 
	{
		height = 0;
	}
	else 
	{
		height = heightHelper(root);
	}
	return height;
}
}

template < typename DataType, class KeyType >
int BSTree<DataType, KeyType>::getCount () const
// Returns the number of nodes in the tree

{
	return counter;
}


#include "show9.cpp"