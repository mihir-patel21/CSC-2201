
#include "BSTree.h"

template <typename DataType, class KeyType>
BSTree<DataType, KeyType>::BSTreeNode::BSTreeNode ( const DataType &nodeDataItem, BSTreeNode *leftPtr, BSTreeNode *rightPtr )
// Creates a binary search tree node containing data item elem, left
// child pointer leftPtr, and right child pointer rightPtr.
  : dataItem(nodeDataItem),
    left(leftPtr),
    right(rightPtr)
{

}

template < typename DataType, typename KeyType >
BSTree<DataType,KeyType>:: BSTree ()

// Creates an empty tree.

{
    root = NULL;
}

template < typename DataType, typename KeyType >
BSTree<DataType,KeyType>:: BSTree ( const BSTree &source )

// Creates an empty tree.

{
    root = NULL;
    copyTree(root, source);
}

template < typename DataType, typename KeyType >
BSTree<DataType,KeyType>& BSTree<DataType,KeyType>:: operator= ( const BSTree &sourceTree )

// Sets a tree to be equivalent to the tree "source".

{
    // Avoid accidentally trying to set object to itself.
    // Calling clear() on an object, then copying the deleted data doesn't work.
    // Although this may seems like overkill and an unlikely scenario, it can happen, 
    if( this != &sourceTree ) 
    {
        clear();
        copyTree(sourceTree);
        return *this;
    }
    clear();
    copyTree(root, source);
    return *this;
}
//--------------------------------------------------------------------

template < typename DataType, typename KeyType >
void BSTree<DataType,KeyType>:: copyTree ( const BSTree<DataType,KeyType> &sourceTree )

// Sets a tree to be equivalent to the tree "source".

{
    copyTreeHelper( root, sourceTree.root );
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

template < typename DataType, typename KeyType >
void BSTree<DataType,KeyType>:: copyTreeHelper ( BSTreeNode *&p, const BSTreeNode *sourcePtr )

// Recursive helper function that helps set a tree to be equivalent to another tree.

{
    if( p != 0 ) {
        p = new BSTreeNode( sourcePtr->DataItem, 0, 0 );
        copyTreeHelper( p->left, sourcePtr->left );
        copyTreeHelper( p->right, sourcePtr->right );
    }
}

template < typename DataType, typename KeyType >
BSTree<DataType,KeyType>:: ~BSTree ()

// Frees the memory used by a tree.

{
    clear();
}

template < typename DataType, typename KeyType >
void BSTree<DataType,KeyType>:: insert ( const DataType &newDataItem )

// Inserts newDataItem into a tree. If an data item with the same key
// as newDataItem already exists in the tree, then updates that
// data item's data with newDataItem's data.

{
    insertHelper(root, newDataItem);
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

template < typename DataType, typename KeyType >
void BSTree<DataType,KeyType>:: insertHelper ( BSTreeNode *&p,
                                 const DataType &newDataItem   )

// Recursive helper function for insert. Inserts newDataItem in
// the subtree pointed to by p.

{
    if ( p == 0 ) // Insert
       p = new BSTreeNode(newDataItem,0,0);
    else if ( newDataItem.getKey() < p->dataItem.getKey() )
       insertHelper(p->left, newDataItem);                  // Search left
    else if ( newDataItem.getKey() > p->dataItem.getKey() )
       insertHelper(p->right, newDataItem);                 // Search right
    else
       p->dataItem = newDataItem;                           // Update
}

//--------------------------------------------------------------------

template < typename DataType, typename KeyType >
void BSTree<DataType,KeyType>:: clear ()

// Removes all the nodes from a tree.

{
    clearHelper(root);
    root = NULL;
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

template < typename DataType, typename KeyType >
void BSTree<DataType,KeyType>:: clearHelper ( BSTreeNode *p )

// Recursive helper for clear. Clears the subtree pointed to by p.

{
    if ( p != 0 )
    {
       // Use post-order traversal. Otherwise get into trouble by
       // referencing p->left and/or p->right after p had been deallocated.
       clearHelper(p->left);
       clearHelper(p->right);
       delete p;
    }
}
//--------------------------------------------------------------------

template < typename DataType, class KeyType >
bool BSTree<DataType, KeyType>::retrieve ( const KeyType& searchKey, DataType& searchDataItem ) const
// Searches a tree for the data item with key searchKey. If the data item
// is found, then copies the data item to searchDataItem and returns true.
// Otherwise, returns false with searchDataItem undefined.
{
    return retrieveHelper(root, key, data);
}

template < typename DataType, class KeyType >
bool BSTree<DataType, KeyType>::remove ( const KeyType& deleteKey )
// Removes the data item with key deleteKey from a tree. If the
// data item is found, then deletes it from the tree and returns true.
// Otherwise, returns false.
{
    removeHelper(root, key);
}

template < typename DataType, class KeyType >
void BSTree<DataType, KeyType>::writeKeys () const
// Outputs the keys in a tree in ascending order.

{
    writeKeyHelper(root);
    cout << endl;
}

template < typename DataType, class KeyType >
bool BSTree<DataType, KeyType>::isEmpty () const

// Returns true if a tree is empty. Otherwise returns false.

{
    return root == NULL;
}

template < typename DataType, class KeyType >
int BSTree<DataType, KeyType>::getHeight () const
// Returns the height of a tree.

{
    return getHeightHelper(root) - 1;
}

template < typename DataType, class KeyType >
int BSTree<DataType, KeyType>::getCount () const
// Returns the number of nodes in the tree

{
    return getCountHelper(root) - 1;
}


#include "show9.cpp"