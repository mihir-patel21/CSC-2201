
#include "Heap.h"

template < typename DataType, typename KeyType, typename Comparator >
Heap<DataType,KeyType,Comparator>::Heap ( int maxNumber = DEFAULT_MAX_HEAP_SIZE )
{
	: maxSize(maxNumber),
		size(0)
	{
		dataItems = new DataType[maxSize];
	}
}

template < typename DataType, typename KeyType, typename Comparator >
Heap<DataType,KeyType,Comparator>::Heap ( const Heap& other )
{
	: maxSize(other.maxSize),
		size(other.size)
	{
		dataItems = new DataType[maxSize];
		for (int i = 0; i < size; i++) 
		{
			dataItems[i] = other.dataItems[i];
		}
	}
}

template < typename DataType, typename KeyType, typename Comparator >
Heap<DataType,KeyType,Comparator>& Heap<DataType,KeyType,Comparator>::operator= ( const Heap& other )
{
	{
		if (this == &other) 
		{
			return *this; 
		}	
		if (other.maxSize > maxSize) 
		{
			delete[] dataItems;
			dataItems = new DataType[other.maxSize];
		}
		maxSize = other.maxSize;
		size = other.size;
		for (int i = 0; i < size; i++) 
		{
			dataItems[i] = other.dataItems[i];
		}

		return *this;
	}
}

template < typename DataType, typename KeyType, typename Comparator >
Heap<DataType,KeyType,Comparator>::~Heap ()
{
	delete[] dataItems;
}

template < typename DataType, typename KeyType, typename Comparator >
void Heap<DataType,KeyType,Comparator>::insert ( const DataType &newDataItem )
    throw ( logic_error )
{
	int parentj;
	j;
	if (size >= maxSize)
	{
		thow logic_error("heap if full");
	}
	j = size;
	parentj = ((j - 1) / 2);

	dataItems[j] = newDataItem;
	size++;

	if (dataItems[j].getPriority() > dataItems[parentj].getPriority()) 
	{
		
		DataType temp = dataItems[parentj];

		dataItems[parentj] = dataItems[j];
		dataItems[j] = temp;
	}
}

template < typename DataType, typename KeyType, typename Comparator >
DataType Heap<DataType,KeyType,Comparator>::remove () throw ( logic_error )
{
	DataType oldMax,    
		insertDataItem;  
	bool stop;         
	int j;              

	
	if (size == 0)
		throw logic_error("heap is empty");


	oldMax = dataItems[0];


	insertDataItem = dataItems[size - 1];
	dataItems[0] = insertDataItem;
	size--;
	clean();

	return insertDataItem;

}

template < typename DataType, typename KeyType, typename Comparator >
void Heap<DataType,KeyType,Comparator>::clear ()
{
	size = 0;
}

template < typename DataType, typename KeyType, typename Comparator >
bool Heap<DataType,KeyType,Comparator>::isEmpty () const
{
	return (size == 0);
}

template < typename DataType, typename KeyType, typename Comparator >
bool Heap<DataType,KeyType,Comparator>::isFull () const
{
	return (size == maxSize);
}

#include "show11.cpp"